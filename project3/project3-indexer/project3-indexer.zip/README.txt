###
# Documentation of Index Design
###

The attributes we chose to include from each of the database tables are:
1. Items : Name, Description
2. ItemCategory: Category (For every item, we fetch the categories related to that item, and build a textfield)
3. Bids: -
4. SellerRating: -
5. Users: -
