DROP INDEX sp_index ON ItemLocation;

DROP TABLE IF EXISTS ItemLocation;

