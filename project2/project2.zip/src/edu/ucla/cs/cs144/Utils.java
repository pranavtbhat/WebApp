package edu.ucla.cs.cs144;

public class Utils {
	public static String escaped(String s){
		return "";
	}
}
